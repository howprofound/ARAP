#include "fish.h"

Fish::Fish()
{
	texture = NULL;
	x = SCREEN_WIDTH / 2;
	y = SCREEN_HEIGHT - 30;
}
Fish::Fish(const char path[])
{
	texture = SDL_LoadBMP(path);
	x = SCREEN_WIDTH / 2;
	y = SCREEN_HEIGHT - 30;
}

SDL_Surface* Fish::getTexture()
{
	return this->texture;
}

void Fish::setX(float x)
{
	this->x = x;
}
float Fish::getX()
{
	return this->x;
}

void Fish::setY(float y)
{
	this->y = y;
}
float Fish::getY()
{
	return this->y;
}

void Fish::setPoints(int points)
{
	this->points = points;
}
int Fish::getPoints()
{
	return this->points;
}